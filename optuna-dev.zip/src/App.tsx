import "@mantine/core/styles.css";
import "@mantine/notifications/styles.css";
import { MantineProvider } from "@mantine/core";
import { Notifications } from "@mantine/notifications";
import theme from "./theme";
import Home from "./pages/Home/Home";
import "mantine-react-table/styles.css";
import { QueryClientProvider, QueryClient } from "@tanstack/react-query";
import { AttributeDataProvider } from "./context/AttributeContext";

// Create QueryClient outside of component to prevent re-creation
const queryClient = new QueryClient();

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <AttributeDataProvider>
        <MantineProvider theme={theme}>
          <Notifications />
          <Home />
        </MantineProvider>
      </AttributeDataProvider>
    </QueryClientProvider>
  );
};

export default App;
