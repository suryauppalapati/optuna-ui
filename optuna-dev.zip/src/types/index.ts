type BrandOptions = {
  name: string;
  logoUrl: string;
};

// API Paramaters

type StoneConfig = {
  stone_size: number;
  stone_count: number;
};

type GCParams = {
  compositionData: Composition[];
  brandAttributes: Record<string, string>;
};

type StoneAttributes = {
  stone_quality: string;
  stone_category: string;
  stone_color: string;
};

// API Responses

type JewelryBrandAttrs = {
  product_group: string[];
  need_state: string[];
  product_category: string[];
  stone_quality: string[];
  stone_category: string[][];
  stone_color: string[];
};

type AttributeData = {
  brandAttributes: JewelryBrandAttrs | {};
  productAttributes: any[];
  stoneAttributes: number[];
};

type CalculatedGCResult = {
  total_f1: number | string;
  total_f2: number | string;
  metal_value: number | string;
  total_price: number | string;
  bmgc: number | string;
  gc: number | string;
};

// Form Input

type Option = {
  value: string;
  label: string;
};

type FormState = {
  product_group: string;
  need_state: string;
  product_category: string;
  stone_quality: string;
  stone_category: string;
  stone_color: string;
  karatage: string;
  product_weight: string;
  design_reference: string;
  [key: string]: string;
};

// Composition Input

type Composition = {
  id: number;
  color: string | null;
  stoneSize: number | null;
  stoneQuantity: number | null;
  stoneSizeTolerance?: number | null;
  minStoneQuantity?: number | null;
  maxStoneQuantity?: number | null;
};

// Constraint Input

type ConstraintData = {
  productConstraint: string;
  minimum: number | null;
  maximum: number | null;
};

export type {
  BrandOptions,
  GCParams,
  StoneConfig,
  StoneAttributes,
  AttributeData,
  JewelryBrandAttrs,
  Option,
  FormState,
  Composition,
  ConstraintData,
  CalculatedGCResult,
};
