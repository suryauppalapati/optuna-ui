import { Option, Composition, StoneConfig, ConstraintData, FormState } from "../types";

export function createOptions(data: Record<string, any[]>): Record<string, Option[]> {
  const options: Record<string, Option[]> = {};

  for (const key in data) {
    if (Array.isArray(data[key])) {
      // To Flatten any nested arrays (like stone_category from response..)
      const flatArray = data[key].flat();

      options[key] = flatArray.map((item) => ({ value: item, label: item }));
    }
  }

  return options;
}

export function createStoneConfigParams(params: Composition[]): StoneConfig[] {
  const stoneConfig = [];
  for (const key in params) {
    if (params[key].stoneSize && params[key].stoneQuantity) {
      stoneConfig.push({ stone_size: params[key]["stoneSize"], stone_count: params[key]["stoneQuantity"] });
    }
  }
  return stoneConfig;
}

// Job Param Utils

function constructProductFilters(formData: FormState, constraintData: ConstraintData[]) {
  const constraintParams = constraintData.reduce((accumulator: any, current: ConstraintData) => {
    const productConstraint = current.productConstraint.replace(/\s+/g, "_").toLowerCase();
    if (current.maximum && current.minimum) {
      accumulator[productConstraint] = {
        mode: "continuous",
        lower_bound: current.minimum,
        upper_bound: current.maximum,
      };
    }
    return accumulator;
  }, {});
  return {
    ...constraintParams,
    stone_quality: {
      mode: "categorical",
      values: [formData.stone_quality],
    },
    stone_color: {
      mode: "categorical",
      values: [formData.stone_color],
    },
  };
}

function constructGroupFilters(compositionData: Composition[], stoneSizes: number[]) {
  const groupFilterParams = compositionData.reduce((accumulator: any, current: Composition) => {
    const selectedStoneSizeIndex = stoneSizes.indexOf(current.stoneSize!);
    const stoneSizesInitialIndex = 0;
    const stoneSizeFinalIndex = stoneSizes.length - 1;

    // Calculate the upper and lower bounds based on the selected stone size and tolerance
    const upper_bound = selectedStoneSizeIndex + current.stoneSizeTolerance!;
    const lower_bound = selectedStoneSizeIndex - current.stoneSizeTolerance!;

    // Clamp the lower and upper bounds within the valid index range
    const clampedLowerBound = Math.max(stoneSizesInitialIndex, Math.min(stoneSizeFinalIndex, lower_bound));
    const clampedUpperBound = Math.max(stoneSizesInitialIndex, Math.min(stoneSizeFinalIndex, upper_bound));

    // Ensure valid bounds for accessing stoneSizes
    const lowerBoundValue = stoneSizes[clampedLowerBound];
    const upperBoundValue = stoneSizes[clampedUpperBound];

    accumulator.push({
      stone_size: {
        mode: "continuous",
        lower_bound: lowerBoundValue,
        upper_bound: upperBoundValue,
      },
      stone_count: {
        mode: "continuous",
        lower_bound: current.minStoneQuantity,
        upper_bound: current.maxStoneQuantity,
      },
    });

    return accumulator;
  }, []);

  return groupFilterParams;
}

export function createJobApiParams(
  formData: FormState,
  constraintData: ConstraintData[],
  compositionData: Composition[],
  stoneSizes: number[]
) {
  const { product_group, need_state, product_category: category, karatage: gold_karat } = formData;

  const product_parameters = { product_group, need_state, category, gold_karat: Number(gold_karat), stone_type: "All" };
  const product_filters = constructProductFilters(formData, constraintData);
  const group_filters = constructGroupFilters(compositionData, stoneSizes);

  const params = {
    product_parameters: product_parameters,
    design_json: {
      product_filters,
      group_filters,
      group_constraints: [],
    },
    gold_rate_22k: 7800,
    num_jobs: 10,
    num_trials: 1500,
    best_trials: 3,
  };

  return params;
}

// Format display values
export function formatDisplayValues(label: string, value: string) {
  console.log("val", value);
  const isGC = label === "gc" || label === "bmgc";
  const isPrice = label === "total_price";
  const isF1F2 = label === "total_f1" || label === "total_f2";
  const isMetal = label === "metal_value";

  if (isGC && !isNaN(parseFloat(value))) {
    return `${(parseFloat(value) * 100).toFixed(2)}%`;
  } else if (isPrice && !isNaN(parseFloat(value))) {
    return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(
      Math.ceil(parseInt(value))
    );
  } else if (isF1F2 && !isNaN(parseFloat(value))) {
    return Math.ceil(parseInt(value));
  } else if (isMetal && !isNaN(parseFloat(value))) {
    return parseFloat(value).toFixed(2);
  } else return value || "-";
}

// Validate a composition object
export const validateRowData = (mode: string, rowData: Partial<Composition>) => {
  const errors: { [key: string]: string | null } = {};

  if (mode === "basic") {
    errors.stoneQuantity = !rowData.stoneQuantity ? "Stone quantity is required and must be greater than 0" : null;
    errors.stoneSize = !rowData.stoneSize ? "Stone size is required" : null;
  }

  if (mode === "advanced") {
    errors.stoneSize = !rowData.stoneSize ? "Stone size is required" : null;
    errors.minStoneQuantity = !rowData.minStoneQuantity ? "Minimum stone quantity is required" : null;
    errors.maxStoneQuantity = !rowData.maxStoneQuantity ? "Maximum stone quantity is required" : null;

    if (rowData.minStoneQuantity && rowData.maxStoneQuantity && rowData.minStoneQuantity > rowData.maxStoneQuantity) {
      errors.minStoneQuantity = "Minimum quantity cannot be greater than maximum quantity";
    }
  }

  return errors;
};

export function validateOnCalculate(formData: FormState, compositionData: Composition[]) {
  const isFormFilled = Object.values(formData).every((value) => value.trim().length > 0);
  const isComposition = compositionData.every((composition) => composition.stoneQuantity && composition.stoneSize);

  return isFormFilled && isComposition;
}

export function validateOnJobSubmit(
  formData: FormState,
  compositionData: Composition[],
  constraintData: ConstraintData[]
): string[] {
  const errors: string[] = [];

  const missingFields = Object.keys(formData).filter((key) => !formData[key] || formData[key].trim().length === 0);

  if (missingFields.length > 0) {
    errors.push(`Missing required fields: ${missingFields.map((key) => key.replace(/_/g, " ")).join(", ")}`);
  }

  // Validate Composition Data
  compositionData.forEach((composition, index) => {
    if (!composition.stoneSize || isNaN(composition.stoneSize)) {
      errors.push(`Composition #${index + 1}: Stone size is required and must be a number.`);
    }
    if (!composition.minStoneQuantity || isNaN(composition.minStoneQuantity)) {
      errors.push(`Composition #${index + 1}: Minimum stone quantity is required and must be a number.`);
    }
  });

  // Validate Constraint Data (excluding specific constraints)
  constraintData
    .filter((crow) => crow.productConstraint !== "Total stone count" && crow.productConstraint !== "Total product price")
    .forEach((constraint) => {
      if (constraint.minimum == null || isNaN(constraint.minimum)) {
        errors.push(`Constraint "${constraint.productConstraint}": Minimum value is required and must be a number.`);
      }
      if (constraint.maximum == null || isNaN(constraint.maximum)) {
        errors.push(`Constraint "${constraint.productConstraint}": Maximum value is required and must be a number.`);
      }
      if (
        typeof constraint.minimum === "number" &&
        typeof constraint.maximum === "number" &&
        constraint.minimum > constraint.maximum
      ) {
        errors.push(`Constraint "${constraint.productConstraint}": Minimum value cannot be greater than Maximum value.`);
      }
    });

  return errors;
}
