import { Grid, Table } from "@mantine/core";
import { useAttributeData } from "../../context/AttributeContext";
import { formatDisplayValues } from "../../utils";

export interface StoneGroup {
  item_code: string;
  stone_size: number;
  stone_count: number;
  stone_weight: number;
  stone_category: string;
  stone_quality: string;
  stone_color: string;
  stone_shape: string;
}

interface CompositionDetailsProps {
  stoneGroups: StoneGroup[];
  jobResult: {
    label: string;
    value: string | number;
    dataIndex: number;
  }[];
  jobStatus: string;
}

const CompositionDetails = ({ stoneGroups, jobResult, jobStatus }: CompositionDetailsProps) => {
  const { data } = useAttributeData();

  return (
    <div style={{ width: "100%" }}>
      <div
        style={{
          margin: "1rem 0",
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          gap: "1rem",
          padding: "0.5rem",
          border: "1px solid rgba(0,0,0,0.1)",
        }}
      >
        {/* Form Values */}
        <Grid>
          {Object.keys(data.formData).length > 0 &&
            Object.keys(data.formData)
              .filter((keyName) => keyName !== "design_reference" && keyName !== "product_weight")
              .map((key) => (
                <Grid.Col span={3} key={key}>
                  <p>
                    {key.replace(/_/g, " ").toUpperCase()}:{" "}
                    <span style={{ fontWeight: "500", margin: "0 0.25rem" }}>{data.formData[key].toUpperCase()}</span>
                  </p>
                </Grid.Col>
              ))}

          {Array.isArray(jobResult) &&
            jobResult.map((item, index) => {
              return (
                <Grid.Col span={3} key={index}>
                  <p key={index}>
                    {item.label.toUpperCase()}: <span style={{ fontWeight: "500", margin: "0 0.25rem" }}>{item.value}</span>
                  </p>
                </Grid.Col>
              );
            })}
          <Grid.Col span={3}>
            <p>
              STATUS:
              <span
                style={{
                  fontWeight: "500",
                  margin: "0 0.25rem",
                  color: jobStatus === "NOT OK" ? "red" : undefined,
                }}
              >
                {jobStatus}
              </span>
            </p>
          </Grid.Col>
        </Grid>
      </div>

      <Table stickyHeader withTableBorder striped stickyHeaderOffset={60} highlightOnHover>
        <Table.Thead>
          <Table.Tr>
            <Table.Th style={{ textAlign: "center" }}>Item Code</Table.Th>
            <Table.Th style={{ textAlign: "center" }}>Stone Size</Table.Th>
            <Table.Th style={{ textAlign: "center" }}>Stone Count</Table.Th>
            <Table.Th style={{ textAlign: "center" }}>Stone Weight</Table.Th>
            <Table.Th style={{ textAlign: "center" }}>Stone Category</Table.Th>
            <Table.Th style={{ textAlign: "center" }}>Stone Quality</Table.Th>
            <Table.Th style={{ textAlign: "center" }}>Stone Color</Table.Th>
            <Table.Th style={{ textAlign: "center" }}>Stone Shape</Table.Th>
          </Table.Tr>
        </Table.Thead>

        <Table.Tbody>
          {stoneGroups.map((stone, idx) => (
            <Table.Tr key={idx}>
              <Table.Td>{stone.item_code}</Table.Td>
              <Table.Td>{stone.stone_size}</Table.Td>
              <Table.Td>{stone.stone_count}</Table.Td>
              <Table.Td>{stone.stone_weight}</Table.Td>
              <Table.Td>{stone.stone_category}</Table.Td>
              <Table.Td>{stone.stone_quality}</Table.Td>
              <Table.Td>{stone.stone_color}</Table.Td>
              <Table.Td>{stone.stone_shape}</Table.Td>
            </Table.Tr>
          ))}
        </Table.Tbody>
      </Table>
    </div>
  );
};

export default CompositionDetails;
