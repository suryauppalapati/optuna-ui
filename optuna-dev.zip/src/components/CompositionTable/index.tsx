import "@mantine/core/styles.css";
import "@mantine/dates/styles.css";
import "./CompositionTable.scss";
import "mantine-react-table/styles.css";
import { useState, useMemo } from "react";
import { MdDeleteForever } from "react-icons/md";
import { IconTrash, IconEdit } from "@tabler/icons-react";
import randomcolor from "randomcolor";
import { ActionIcon, Button, Loader, NumberInput, Switch, Tooltip } from "@mantine/core";
import { ContextState, initialConstraintData, useAttributeData } from "../../context/AttributeContext";
import {
  MantineReactTable,
  useMantineReactTable,
  type MRT_ColumnDef,
  type MRT_TableOptions,
  type MRT_Row,
} from "mantine-react-table";
import { notifications } from "@mantine/notifications";
import { validateRowData } from "../../utils";
import { Composition } from "../../types";

type compositionProps = {
  stoneSizes: number[];
  calculateGC: () => Promise<void>;
  submitJob: () => Promise<void>;
  isLoading: boolean;
};

export const CompositionTable: React.FC<compositionProps> = ({ stoneSizes, calculateGC, submitJob, isLoading }) => {
  const [tableData, setTableData] = useState<Composition[]>([]);
  const [creatingRowData, setCreatingRowData] = useState<Partial<Composition>>({});
  const { data, setData } = useAttributeData();

  // Check if all required form data fields are filled
  const isFormFilled = useMemo(() => Object.values(data.formData).every((value) => value !== ""), [data.formData]);
  const isAdvancedMode = useMemo(() => data.compositionMode === "advanced", [data.compositionMode]);

  function parseNumberOrNull(val: unknown): number | null {
    if (val === "" || val === undefined || val === null) return null;
    const parsed = Number(val);
    return Number.isNaN(parsed) ? null : parsed;
  }

  function parseStringOrNull(val: unknown): string | null {
    if (val === "" || val === undefined || val === null) return null;
    return String(val);
  }

  const handleCreateComposition: MRT_TableOptions<Composition>["onCreatingRowSave"] = async ({
    values,
    exitCreatingMode,
  }) => {
    const mergedRow: Composition = {
      id: tableData.length ? tableData[tableData.length - 1].id + 1 : 1,

      color: parseStringOrNull(creatingRowData.color) ?? parseStringOrNull(values.color) ?? randomcolor(),
      stoneSize: parseNumberOrNull(creatingRowData.stoneSize) ?? parseNumberOrNull(values.stoneSize),
      stoneQuantity: parseNumberOrNull(creatingRowData.stoneQuantity) ?? parseNumberOrNull(values.stoneQuantity),
      stoneSizeTolerance:
        parseNumberOrNull(creatingRowData.stoneSizeTolerance) ?? parseNumberOrNull(values.stoneSizeTolerance) ?? 0,
      minStoneQuantity: parseNumberOrNull(creatingRowData.minStoneQuantity) ?? parseNumberOrNull(values.minStoneQuantity),
      maxStoneQuantity: parseNumberOrNull(creatingRowData.maxStoneQuantity) ?? parseNumberOrNull(values.maxStoneQuantity),
    };

    const errors = validateRowData(data.compositionMode, mergedRow);
    const errorMessages = Object.values(errors).filter(Boolean);

    if (errorMessages.length > 0) {
      errorMessages.forEach((err) => {
        notifications.show({
          color: "red",
          withBorder: true,
          position: "top-right",
          title: "Validation Error",
          message: err,
        });
      });
      return;
    }

    setTableData((prev) => [...prev, mergedRow]);
    setData((prev: ContextState) => ({
      ...prev,
      compositionData: [...prev.compositionData, mergedRow],
    }));

    setCreatingRowData({});
    exitCreatingMode();
  };

  const updateData = (newData: Composition[]) => {
    setData((prev: ContextState) => ({
      ...prev,
      compositionData: newData,
    }));
  };

  const handleEditingRowSave: MRT_TableOptions<Composition>["onEditingRowSave"] = async ({ row, exitEditingMode }) => {
    const index = tableData.findIndex((composition) => composition.id === row.original.id);
    if (index === -1) {
      console.error("Row not found");
      exitEditingMode();
      setCreatingRowData({});
      return;
    }

    const newCompositionData = [...tableData];
    newCompositionData[index] = { ...tableData[index], ...creatingRowData };

    const errors = validateRowData(data.compositionMode, newCompositionData[index]);
    const errorMessages = Object.values(errors).filter(Boolean);

    if (errorMessages.length > 0) {
      errorMessages.map((err) => {
        notifications.show({
          color: "red",
          withBorder: true,
          position: "top-right",
          title: "Validation Error",
          message: err,
        });
      });
      setCreatingRowData({});
      return;
    }

    setCreatingRowData({});
    setTableData(newCompositionData);
    updateData(newCompositionData);
    exitEditingMode();
  };

  // Delete a composition row from the table
  const handleDeleteRow = (row: MRT_Row<Composition>) => {
    setTableData((prev) => prev.filter((comp) => comp.id !== row.original.id));
    setData((prev: ContextState) => ({
      ...prev,
      compositionData: prev.compositionData.filter((comp) => comp.id !== row.original.id),
    }));
  };

  // Define table columns
  const columns = useMemo<MRT_ColumnDef<Composition>[]>(
    () => [
      {
        accessorKey: "id",
        header: "ID",
        enableEditing: false,
        size: isAdvancedMode ? 40 : 80,
        mantineTableBodyCellProps: { style: { textAlign: "center", display: "none" } },
      },
      {
        accessorKey: "color",
        header: "Color",
        enableEditing: false,
        size: isAdvancedMode ? 75 : undefined,
        Cell: ({ row }) => (
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center", cursor: "not-allowed" }}>
            <div
              style={{
                width: 20,
                height: 20,
                borderRadius: "50%",
                backgroundColor: row.original.color ? row.original.color : "transparent",
              }}
            />
          </div>
        ),
        mantineTableBodyCellProps: { style: { textAlign: "center" } },
      },
      {
        accessorKey: "stoneSize",
        header: "Stone Size",
        size: isAdvancedMode ? 150 : undefined,
        Edit: ({ cell }) => {
          const initialValue = cell.getValue<number>();
          const [inputValue, setInputValue] = useState<number>(initialValue);

          return (
            <NumberInput
              className='inputSelect'
              value={inputValue}
              step={0.05}
              onChange={(value) => {
                if (typeof value === "number") {
                  setInputValue(value);
                  setCreatingRowData((prev) => ({ ...prev, stoneSize: value as number }));
                }
              }}
              onBlur={() => {
                if (!stoneSizes.length) {
                  console.error("stoneSizes array is empty. Cannot find nearest size.");
                  return;
                }

                // Find the nearest valid stone size
                const nearestSize = stoneSizes.reduce(
                  (prev, curr) => (Math.abs(curr - inputValue) < Math.abs(prev - inputValue) ? curr : prev),
                  stoneSizes[0]
                );
                setInputValue(nearestSize);
                setCreatingRowData((prev) => ({ ...prev, stoneSize: nearestSize as number }));
              }}
              min={Math.min(...stoneSizes)}
              max={Math.max(...stoneSizes)}
            />
          );
        },
      },
      {
        accessorKey: "stoneQuantity",
        header: "Stone Quantity",
        size: isAdvancedMode ? 150 : undefined,
        Edit: ({ cell }) => (
          <NumberInput
            className='inputSelect'
            min={1}
            defaultValue={cell.getValue<number>()} // existing value
            onChange={(value) => {
              if (typeof value === "number") {
                setCreatingRowData((prev) => ({ ...prev, stoneQuantity: value as number }));
              }
            }}
          />
        ),
      },
    ],
    [stoneSizes, isAdvancedMode, data.compositionData]
  );

  // Remove stone quality column
  const filterColumn = (key: string) => {
    const filteredColumns = Object.keys(columns)
      .filter((colKey: any) => columns[colKey].accessorKey !== key)
      .map((colKey: any) => columns[colKey]);

    return filteredColumns;
  };

  const advancedModeColumns = useMemo<MRT_ColumnDef<Composition>[]>(() => {
    const stoneSizeToleranceColumn: MRT_ColumnDef<Composition> = {
      accessorKey: "stoneSizeTolerance",
      header: "Stone Size Tol.",
      size: isAdvancedMode ? 125 : undefined,
      Edit: ({ cell }) => (
        <NumberInput
          min={0}
          max={5}
          className='inputSelect'
          defaultValue={cell.getValue<number>()} // existing value
          onChange={(value) => {
            if (typeof value === "number") {
              setCreatingRowData((prev) => ({ ...prev, stoneSizeTolerance: value as number }));
            }
          }}
        />
      ),
    };

    const minStoneQuantity: MRT_ColumnDef<Composition> = {
      accessorKey: "minStoneQuantity",
      header: "Min. Stone Qty",
      size: isAdvancedMode ? 150 : undefined,
      Edit: ({ cell }) => (
        <NumberInput
          min={1}
          className='inputSelect'
          defaultValue={cell.getValue<number>()} // existing value
          onChange={(value) => {
            if (typeof value === "number") {
              setCreatingRowData((prev) => ({ ...prev, minStoneQuantity: value as number }));
            }
          }}
        />
      ),
    };

    const maxStoneQuantity: MRT_ColumnDef<Composition> = {
      accessorKey: "maxStoneQuantity",
      header: "Max. Stone Qty",
      size: isAdvancedMode ? 150 : undefined,
      Edit: ({ cell }) => (
        <NumberInput
          min={1}
          className='inputSelect'
          defaultValue={cell.getValue<number>()} // existing value
          onChange={(value) => {
            if (typeof value === "number") {
              setCreatingRowData((prev) => ({ ...prev, maxStoneQuantity: value as number }));
            }
          }}
        />
      ),
    };

    const filteredColumns = filterColumn("stoneQuantity");
    return [...filteredColumns, stoneSizeToleranceColumn, minStoneQuantity, maxStoneQuantity];
  }, [columns, setCreatingRowData, isAdvancedMode, data.compositionData]);

  const tableColumns = useMemo(() => {
    if (data.compositionMode === "advanced") return advancedModeColumns;
    else return columns;
  }, [isAdvancedMode, columns]);

  // Configure MantineReactTable
  const table = useMantineReactTable({
    columns: tableColumns,
    data: tableData,
    createDisplayMode: "row",
    editDisplayMode: "row",
    enableEditing: true,
    enableRowActions: true,
    enableFilters: false,
    enableFullScreenToggle: false,
    enableHiding: false,
    enableDensityToggle: false,
    enableStickyHeader: true,
    enableSorting: false,
    enableColumnActions: false,
    mantineTableContainerProps: { style: { textAlign: "center" } },
    enablePagination: false,
    positionActionsColumn: "last",
    renderBottomToolbar: () => (
      <div style={{ display: "flex", justifyContent: "center", padding: "0.5rem", border: "1px solid rgba(0,0,0,0.1)" }}>
        <Button
          size='compact-sm'
          disabled={!tableData.length || isLoading}
          onClick={isAdvancedMode ? submitJob : calculateGC}
        >
          {isLoading ? <Loader size={15} color='#5C68AC' /> : data.compositionMode === "basic" ? "Calculate" : "Submit Job"}
        </Button>
      </div>
    ),
    initialState: {
      columnVisibility: {
        id: false, //hide Id column by default
        "mrt-row-expand": false, //hide row expand column by default
      },
    },
    getRowId: (row) => String(row.id),
    onCreatingRowSave: handleCreateComposition,
    onEditingRowSave: handleEditingRowSave,
    onCreatingRowCancel: () => setCreatingRowData({}),
    renderRowActions: ({ row }) => (
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "0.5rem" }}>
        <Tooltip label='Edit'>
          <ActionIcon variant='transparent' size='1.25rem' onClick={() => table.setEditingRow(row)}>
            <IconEdit />
          </ActionIcon>
        </Tooltip>
        <Tooltip label='Delete'>
          <ActionIcon variant='transparent' size='1.25rem' color='red' onClick={() => handleDeleteRow(row)}>
            <IconTrash />
          </ActionIcon>
        </Tooltip>
      </div>
    ),
    renderTopToolbarCustomActions: () => (
      <div style={{ display: "flex", justifyContent: "space-between", width: "100%" }}>
        {
          <Switch
            disabled={!isFormFilled}
            checked={data.compositionMode === "advanced"}
            onChange={(e) => {
              const newMode = e.currentTarget.checked ? "advanced" : "basic";

              // Transform rows based on the selected modde
              let transformedData = data.compositionData.map((row) => {
                if (newMode === "advanced") {
                  // Basic to Advanced switching
                  // If min/maxStoneQuantity were never set, copy stoneQuantity into them
                  return {
                    ...row,
                    minStoneQuantity: row.stoneQuantity,
                    maxStoneQuantity: row.stoneQuantity,
                    stoneSizeTolerance: 0,
                  };
                } else {
                  // Advanced to Basic switching
                  return {
                    ...row,
                    stoneQuantity: row.minStoneQuantity ?? null,
                  };
                }
              });

              setData((prev: ContextState) => ({
                ...prev,
                compositionMode: newMode,
                compositionData: transformedData,
              }));

              setTableData(transformedData);
            }}
            label={data.compositionMode === "advanced" ? "Advanced" : "Basic"}
          />
        }
        <div className='btnGroup'>
          <ActionIcon
            className='deleteBtn'
            variant='transparent'
            onClick={() => {
              setData((prev: ContextState) => ({ ...prev, compositionData: [], constraintData: initialConstraintData }));
              setTableData([]);
            }}
            disabled={!isFormFilled || !data.compositionData.length}
          >
            <MdDeleteForever size={32} />
          </ActionIcon>
          <Button
            size='compact-sm'
            disabled={!stoneSizes.length || !isFormFilled || isLoading}
            variant='filled'
            onClick={() => table.setCreatingRow(true)}
          >
            {data.isStoneSizesFetching ? <Loader size={10} /> : "Add New"}
          </Button>
        </div>
      </div>
    ),
  });

  return (
    <div className='tableContainer' style={{ maxWidth: data.compositionMode === "advanced" ? "75%" : "50%" }}>
      <MantineReactTable table={table} />
    </div>
  );
};
