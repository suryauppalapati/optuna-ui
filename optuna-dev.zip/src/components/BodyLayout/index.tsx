import React, { useEffect, useRef, useState } from "react";
import { calculateGC, submitJobRequest } from "../../apis";
import styles from "./Layout.module.scss";
import ConstraintTable from "../ConstraintTable";
import { CompositionTable } from "../CompositionTable";
import { ContextState, initialGCResultData, useAttributeData } from "../../context/AttributeContext";
import { createJobApiParams, validateOnCalculate, validateOnJobSubmit } from "../../utils";
import { notifications } from "@mantine/notifications";

const BodyLayout: React.FC<{ openJobStatus: () => void }> = ({ openJobStatus }) => {
  const { data, setData } = useAttributeData();
  const { formData, compositionData, constraintData, stoneAttributes, compositionMode } = data;
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const ref = useRef<HTMLDivElement | null>(null);

  const handleCalculateGC = async () => {
    const isValidated = validateOnCalculate(formData, compositionData);
    if (!isValidated) {
      notifications.show({
        color: "red",
        style: { fontSize: "2vw" },
        withBorder: true,
        position: "top-right",
        title: "Error",
        message: "Stone quantity and stone size inputs are required",
      });
      return;
    }
    try {
      setIsLoading(true);
      const response = await calculateGC(data.compositionData, data.formData, data.selectedBrand);
      setData((prev: ContextState) => ({ ...prev, gcResult: [response] }));
      setIsLoading(false);
    } catch (error) {
      notifications.show({
        color: "red",
        style: { fontSize: "2vw" },
        withBorder: true,
        position: "top-right",
        title: "Error",
        message: "GC Calculation failed, please try again!",
      });
      console.error(error);
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (compositionMode === "basic" && compositionData.length > 0) {
      handleCalculateGC();
    }

    if (!compositionData.length) {
      setData((prev: ContextState) => ({ ...prev, gcResult: initialGCResultData }));
    }
  }, [compositionMode, compositionData]);

  const submitJob = async () => {
    const ValidationErrors = validateOnJobSubmit(formData, compositionData, constraintData);
    if (ValidationErrors.length > 0) {
      ValidationErrors.forEach((err) => {
        notifications.show({
          color: "red",
          style: { fontSize: "2vw" },
          withBorder: true,
          position: "top-right",
          title: "Missing data",
          message: err,
        });
      });
      return;
    }

    try {
      setIsLoading(true);
      const params = createJobApiParams(formData, constraintData, compositionData, stoneAttributes);
      const response = await submitJobRequest(params);
      setData((prev: ContextState) => ({ ...prev, jobId: response }));
      // console.log("Job Submitted ID: ", response);
      setIsLoading(false);
      openJobStatus();
    } catch (error) {
      notifications.show({
        color: "red",
        style: { fontSize: "2vw" },
        withBorder: true,
        position: "top-right",
        title: "Error",
        message: "Job request failed, please try again!",
      });
      console.error(error);
      setIsLoading(false);
      console.error(error);
      setIsLoading(false);
    }
  };

  return (
    <div className={styles.root} ref={ref}>
      <div className={styles.tablesContainer}>
        <CompositionTable
          stoneSizes={data.stoneAttributes}
          calculateGC={handleCalculateGC}
          submitJob={submitJob}
          isLoading={isLoading}
        />
        {data.compositionMode === "advanced" && <ConstraintTable />}
      </div>
    </div>
  );
};

export default BodyLayout;
