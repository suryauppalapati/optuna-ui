import { useEffect, useState } from "react";
import styles from "./CompositionResults.module.scss";
import { ContextState, initialGCResultData, useAttributeData } from "../../context/AttributeContext";
import { FaAngleRight, FaAngleLeft } from "react-icons/fa";
import { Button, Modal } from "@mantine/core";
import CompositionDetails from "../CompositionDetails";
import { formatDisplayValues } from "../../utils";

const RESULTS_COUNT = 2; // Max results(in terms of indices) returned by GC Adv. calculator

const CompositionResults = () => {
  const [isOpen, setIsOpen] = useState(false);
  const {
    data: { gcResult, compositionMode },
    setData,
  } = useAttributeData();
  const [resultIndex, setResultIndex] = useState<number>(0);

  // Build a single data structure from gcResult
  //   --> "allItems" includes stone_groups
  //   --> "filteredItems" excludes stone_groups for KPI card display
  const dataList = gcResult.map((row, dataIndex) => {
    const items = Object.entries(row).map(([key, val]) => ({
      label: key.replace(/_/g, " ").toLowerCase(),
      value: val ? formatDisplayValues(key, val.toString()) : Boolean(val) ? val : "-",
      dataIndex,
    }));

    return {
      allItems: items,
      filteredItems: items.filter((item) => item.label !== "stone groups"),
    };
  });

  // Retrieve the arrays needed for the current index
  const currentData = dataList[resultIndex] ?? { allItems: [], filteredItems: [] };
  const { allItems, filteredItems } = currentData;

  // Infer result ["OK"/"NOT OK"/"-"] based on "gc" and "bmgc" values..
  const calculateResult = (): string => {
    const gcValueRaw = filteredItems.find((item) => item.label === "gc")?.value;
    const bmgcValueRaw = filteredItems.find((item) => item.label === "bmgc")?.value;
    if (!gcValueRaw || !bmgcValueRaw) return "-";

    // Type conversion for comparison
    const gcValue = parseFloat(typeof gcValueRaw === "number" ? gcValueRaw.toString() : gcValueRaw);
    const bmgcValue = parseFloat(typeof bmgcValueRaw === "number" ? bmgcValueRaw.toString() : bmgcValueRaw);

    console.log("gcValue", typeof gcValue);
    console.log("bmgcValue", typeof bmgcValue);

    if (isNaN(gcValue) || isNaN(bmgcValue)) return "-";

    const percentage = (gcValue / bmgcValue) * 100;

    if (percentage >= 97 && percentage <= 100) {
      return "OK-THRESH";
    } else if (percentage > 100) {
      return "OK";
    } else if (percentage < 97) {
      return "NOT OK";
    } else return "-";
  };

  const gcFinalResult = calculateResult();

  // Extract "stone_groups" array
  const stoneGroupsItem = allItems.find((item) => item.label === "stone groups");
  const stoneGroups = Array.isArray(stoneGroupsItem?.value) ? stoneGroupsItem.value : [];

  // Reset context data whenever compositionMode changes
  useEffect(() => {
    setData((prev: ContextState) => ({ ...prev, gcResult: initialGCResultData }));
  }, [compositionMode]);

  const handleClose = () => {
    setIsOpen((prev) => !prev);
  };

  return (
    <div
      className={styles.compositionResults}
      onClick={() => {
        if (dataList.length > 1) {
          setIsOpen((prev) => !prev);
        }
      }}
    >
      <Modal size='auto' opened={isOpen} onClose={handleClose} closeOnClickOutside={true} centered>
        <CompositionDetails stoneGroups={stoneGroups} jobResult={filteredItems} jobStatus={gcFinalResult} />
      </Modal>
      {dataList.length > 1 && (
        <>
          <Button size='xs' variant='transparent' className={styles.resultOption}>
            {`Result Variant ${resultIndex + 1}`}
          </Button>
          <FaAngleLeft
            className={`${styles.arrowLeft} ${styles.arrow}`}
            onClick={(e) => {
              e.stopPropagation();
              setResultIndex((prev) => (prev === 0 ? RESULTS_COUNT : prev - 1));
            }}
          />
          <FaAngleRight
            className={`${styles.arrowRight} ${styles.arrow}`}
            onClick={(e) => {
              e.stopPropagation();
              setResultIndex((prev) => (prev === RESULTS_COUNT ? 0 : prev + 1));
            }}
          />
        </>
      )}

      <div className={styles.kpiGrid}>
        {filteredItems.map((item, kpiIndex) => {
          return (
            <div key={kpiIndex} className={styles.kpiCard}>
              <span className={styles.metricLabel}>{item.label}</span>
              <span className={styles.metricValue}>{item.value}</span>
            </div>
          );
        })}
        <div className={styles.kpiCard}>
          <span className={styles.metricLabel}>Status</span>
          <span
            className={`${styles.metricValue} ${styles.result} ${
              gcFinalResult === "NOT OK" ? styles.failed : gcFinalResult === "OK" ? styles.success : ""
            }`}
          >
            {gcFinalResult}
          </span>
        </div>
      </div>
    </div>
  );
};

export default CompositionResults;
