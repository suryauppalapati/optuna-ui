import { useState, useEffect, RefObject } from "react";

interface Dimensions {
  width: number;
  height: number;
}

export function useDimensions<T extends HTMLElement>(elementRef: RefObject<T | null>): [Dimensions] {
  const [dimensions, setDimensions] = useState<Dimensions>({ width: 0, height: 0 });

  useEffect(() => {
    const el = elementRef.current;
    if (el) {
      setDimensions({
        width: el.clientWidth,
        height: el.clientHeight,
      });
    }
  }, [elementRef]);

  return [dimensions];
}
