import "@mantine/core/styles.css";
import "@mantine/dates/styles.css";
import "./CompositionTable.scss";
import "mantine-react-table/styles.css";
import { useState, useMemo } from "react";
import { MdDeleteForever } from "react-icons/md";
import { IconTrash, IconEdit } from "@tabler/icons-react";
import { ActionIcon, Button, Loader, NumberInput, Switch, Tooltip } from "@mantine/core";
import { ContextState, initialConstraintData, useAttributeData } from "../../context/AttributeContext";
import {
  MantineReactTable,
  useMantineReactTable,
  type MRT_ColumnDef,
  type MRT_TableOptions,
  type MRT_Row,
} from "mantine-react-table";
import { notifications } from "@mantine/notifications";
import { validateRowData } from "../../utils";

export type Composition = {
  id: number;
  color: string;
  stoneSize: number;
  stoneQuantity: number;
  stoneSizeTolerance?: number;
  minStoneQuantity?: number;
  maxStoneQuantity?: number;
};

export const CompositionTable: React.FC<{ stoneSizes: number[] }> = ({ stoneSizes }) => {
  const [tableData, setTableData] = useState<Composition[]>([]);
  const [creatingRowData, setCreatingRowData] = useState<Partial<Composition>>({});
  const { data, setData } = useAttributeData();

  // Check if all required form data fields are filled
  const isFormFilled = useMemo(() => Object.values(data.formData).every((value) => value !== ""), [data.formData]);
  const isAdvancedMode = useMemo(() => data.compositionMode === "advanced", [data.compositionMode]);

  // Create a new composition row in the table
  const handleCreateComposition: MRT_TableOptions<Composition>["onCreatingRowSave"] = async ({
    values,
    exitCreatingMode,
  }) => {
    const isAdvancedMode = data.compositionMode === "advanced";
    const newRow: Composition = {
      id: tableData.length ? tableData[tableData.length - 1].id + 1 : 1, // Auto-increment ID
      color: "red", // Hardcoded color
      stoneQuantity: creatingRowData.stoneQuantity ?? values.stoneQuantity,
      stoneSize: creatingRowData.stoneSize ?? values.stoneSize ?? stoneSizes[0],
      minStoneQuantity: creatingRowData.stoneQuantity ?? values.stoneQuantity,
      maxStoneQuantity: creatingRowData.stoneQuantity ?? values.stoneQuantity,
      stoneSizeTolerance: creatingRowData.stoneSizeTolerance ?? values.stoneSizeTolerance ?? 0,
    };
    const newComposition = isAdvancedMode
      ? {
          ...newRow,
          stoneSizeTolerance: creatingRowData.stoneSizeTolerance ?? values.stoneSizeTolerance ?? 0,
          minStoneQuantity: creatingRowData.minStoneQuantity ?? values.minStoneQuantity,
          maxStoneQuantity: creatingRowData.maxStoneQuantity ?? values.maxStoneQuantity,
          stoneQuantity: creatingRowData.minStoneQuantity ?? values.stoneQuantity,
        }
      : newRow;

    const errors = validateRowData(data.compositionMode, newComposition);
    const errorMessages = Object.values(errors).filter(Boolean);

    if (errorMessages.length > 0) {
      errorMessages.map((err) => {
        notifications.show({
          color: "red",
          withBorder: true,
          position: "top-right",
          title: "Validation Error",
          message: err,
        });
      });
      setCreatingRowData({});
      return;
    }

    setTableData((prev) => [...prev, newComposition]);
    setData((prev: ContextState) => ({
      ...prev,
      compositionData: [...prev.compositionData, newComposition],
    }));

    setCreatingRowData({});
    exitCreatingMode();
  };

  const updateData = (newData: Composition[]) => {
    setData((prev: ContextState) => ({
      ...prev,
      compositionData: newData,
    }));
  };

  const handleEditingRowSave: MRT_TableOptions<Composition>["onEditingRowSave"] = async ({
    row,
    values,
    exitEditingMode,
  }) => {
    const isAdvancedMode = data.compositionMode === "advanced";
    const newRow: Composition = {
      id: row.original.id,
      color: creatingRowData.color ?? values.color,
      stoneQuantity: creatingRowData.stoneQuantity ?? values.stoneQuantity,
      stoneSize: creatingRowData.stoneSize ?? values.stoneSize,
      minStoneQuantity: creatingRowData.stoneQuantity ?? values.minStoneQuantity,
      maxStoneQuantity: creatingRowData.stoneQuantity ?? values.maxStoneQuantity,
      stoneSizeTolerance: creatingRowData.stoneSizeTolerance ?? values.stoneSizeTolerance ?? 0,
    };

    const newComposedRow: Composition = isAdvancedMode
      ? {
          ...newRow,
          stoneSizeTolerance: creatingRowData.stoneSizeTolerance ?? values.stoneSizeTolerance ?? 0,
          minStoneQuantity: creatingRowData.minStoneQuantity ?? values.minStoneQuantity,
          maxStoneQuantity: creatingRowData.maxStoneQuantity ?? values.maxStoneQuantity,
          stoneQuantity: creatingRowData.minStoneQuantity ?? values.stoneQuantity,
        }
      : newRow;

    // Find the index of the row by matching the unique productConstraint field
    const index = data.compositionData.findIndex((composition) => composition.id === row.original.id);
    if (index === -1) {
      console.error("Row not found");
      exitEditingMode();
      return;
    }

    const errors = validateRowData(data.compositionMode, newComposedRow);
    const errorMessages = Object.values(errors).filter(Boolean);

    if (errorMessages.length > 0) {
      errorMessages.map((err) => {
        notifications.show({
          color: "red",
          withBorder: true,
          position: "top-right",
          title: "Validation Error",
          message: err,
        });
      });
      setCreatingRowData({});
      return;
    }

    const newCompositionData = [...data.compositionData];
    newCompositionData[index] = newComposedRow;
    setTableData(newCompositionData);
    updateData(newCompositionData);
    exitEditingMode();
  };

  // Delete a composition row from the table
  const handleDeleteRow = (row: MRT_Row<Composition>) => {
    setTableData((prev) => prev.filter((comp) => comp.id !== row.original.id));
    setData((prev: ContextState) => ({
      ...prev,
      compositionData: prev.compositionData.filter((comp) => comp.id !== row.original.id),
    }));
  };

  // Define table columns
  const columns = useMemo<MRT_ColumnDef<Composition>[]>(
    () => [
      {
        accessorKey: "id",
        header: "ID",
        enableEditing: false,
        size: isAdvancedMode ? 40 : 80,
        mantineTableBodyCellProps: { style: { textAlign: "center", display: "none" } },
      },
      {
        accessorKey: "color",
        header: "Color",
        enableEditing: false,
        size: isAdvancedMode ? 75 : undefined,
        Cell: ({ row }) => (
          <div style={{ display: "flex", justifyContent: "center", alignItems: "center", cursor: "not-allowed" }}>
            <div
              style={{
                width: 20,
                height: 20,
                borderRadius: "50%",
                backgroundColor: row.original.color,
              }}
            />
          </div>
        ),
        mantineTableBodyCellProps: { style: { textAlign: "center", cursor: "not-allowed" } },
      },
      {
        accessorKey: "stoneSize",
        header: "Stone Size",
        size: isAdvancedMode ? 150 : undefined,
        Edit: ({ cell }) => {
          const initialValue = cell.getValue<number>();
          const [inputValue, setInputValue] = useState<number>(initialValue);

          return (
            <NumberInput
              className='inputSelect'
              value={inputValue}
              step={0.05}
              onChange={(value) => {
                if (typeof value === "number") {
                  setInputValue(value);
                  setCreatingRowData((prev) => ({ ...prev, stoneSize: value }));
                }
              }}
              onBlur={() => {
                if (!stoneSizes.length) {
                  console.error("stoneSizes array is empty. Cannot find nearest size.");
                  return;
                }

                // Find the nearest valid stone size
                const nearestSize = stoneSizes.reduce(
                  (prev, curr) => (Math.abs(curr - inputValue) < Math.abs(prev - inputValue) ? curr : prev),
                  stoneSizes[0]
                );
                setInputValue(nearestSize);
                setCreatingRowData((prev) => ({ ...prev, stoneSize: nearestSize }));
              }}
              min={Math.min(...stoneSizes)}
              max={Math.max(...stoneSizes)}
            />
          );
        },
      },
      {
        accessorKey: "stoneQuantity",
        header: "Stone Quantity",
        size: isAdvancedMode ? 150 : undefined,
        Edit: ({ cell }) => (
          <NumberInput
            className='inputSelect'
            min={1}
            defaultValue={cell.getValue<number>()} // existing value
            onChange={(value) => {
              if (typeof value === "number") {
                setCreatingRowData((prev) => ({ ...prev, stoneQuantity: value }));
              }
            }}
          />
        ),
      },
    ],
    [stoneSizes, isAdvancedMode, data.compositionData]
  );

  // Remove stone quality column
  const filterColumn = (key: string) => {
    const filteredColumns = Object.keys(columns)
      .filter((colKey: any) => columns[colKey].accessorKey !== key)
      .map((colKey: any) => columns[colKey]);

    return filteredColumns;
  };

  const advancedModeColumns = useMemo<MRT_ColumnDef<Composition>[]>(() => {
    const stoneSizeToleranceColumn: MRT_ColumnDef<Composition> = {
      accessorKey: "stoneSizeTolerance",
      header: "Stone Size Tol.",
      size: isAdvancedMode ? 125 : undefined,
      Edit: ({ cell }) => (
        <NumberInput
          min={0}
          max={5}
          className='inputSelect'
          defaultValue={cell.getValue<number>()} // existing value
          onChange={(value) => {
            if (typeof value === "number") {
              setCreatingRowData((prev) => ({ ...prev, stoneSizeTolerance: value }));
            }
          }}
        />
      ),
    };

    const minStoneQuantity: MRT_ColumnDef<Composition> = {
      accessorKey: "minStoneQuantity",
      header: "Min. Stone Qty",
      size: isAdvancedMode ? 150 : undefined,
      Edit: ({ cell }) => (
        <NumberInput
          min={0}
          className='inputSelect'
          defaultValue={cell.getValue<number>()} // existing value
          onChange={(value) => {
            if (typeof value === "number") {
              setCreatingRowData((prev) => ({ ...prev, minStoneQuantity: value }));
            }
          }}
        />
      ),
    };

    const maxStoneQuantity: MRT_ColumnDef<Composition> = {
      accessorKey: "maxStoneQuantity",
      header: "Max. Stone Qty",
      size: isAdvancedMode ? 150 : undefined,
      Edit: ({ cell }) => (
        <NumberInput
          min={0}
          className='inputSelect'
          defaultValue={cell.getValue<number>()} // existing value
          onChange={(value) => {
            if (typeof value === "number") {
              setCreatingRowData((prev) => ({ ...prev, maxStoneQuantity: value }));
            }
          }}
        />
      ),
    };

    const filteredColumns = filterColumn("stoneQuantity");
    return [...filteredColumns, stoneSizeToleranceColumn, minStoneQuantity, maxStoneQuantity];
  }, [columns, setCreatingRowData, isAdvancedMode, data.compositionData]);

  const tableColumns = useMemo(() => {
    if (data.compositionMode === "advanced") return advancedModeColumns;
    else return columns;
  }, [isAdvancedMode, columns]);

  // Configure MantineReactTable
  const table = useMantineReactTable({
    columns: tableColumns,
    data: tableData,
    createDisplayMode: "row",
    editDisplayMode: "row",
    enableEditing: true,
    enableRowActions: true,
    enableFilters: false,
    enableFullScreenToggle: false,
    enableHiding: false,
    enableDensityToggle: false,
    enableStickyHeader: true,
    enableSorting: false,
    enableColumnActions: false,
    mantineTableContainerProps: { style: { textAlign: "center" } },
    enablePagination: false,
    positionActionsColumn: "last",
    renderBottomToolbar: "",
    initialState: {
      columnVisibility: {
        id: false, //hide Id column by default
        "mrt-row-expand": false, //hide row expand column by default
      },
    },
    getRowId: (row) => String(row.id),
    onCreatingRowSave: handleCreateComposition,
    onEditingRowSave: handleEditingRowSave,

    renderRowActions: ({ row }) => (
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: "0.5rem" }}>
        <Tooltip label='Edit'>
          <ActionIcon variant='transparent' size='1.25rem' onClick={() => table.setEditingRow(row)}>
            <IconEdit />
          </ActionIcon>
        </Tooltip>
        <Tooltip label='Delete'>
          <ActionIcon variant='transparent' size='1.25rem' color='red' onClick={() => handleDeleteRow(row)}>
            <IconTrash />
          </ActionIcon>
        </Tooltip>
      </div>
    ),
    renderTopToolbarCustomActions: () => (
      <div style={{ display: "flex", justifyContent: "space-between", width: "100%" }}>
        {
          <Switch
            disabled={!isFormFilled}
            checked={data.compositionMode === "advanced"}
            onChange={(e) =>
              setData((prev: ContextState) => ({
                ...prev,
                compositionMode: e.currentTarget?.checked ? "advanced" : "basic",
              }))
            }
            label={data.compositionMode === "advanced" ? "Advanced" : "Basic"}
          />
        }
        <div className='btnGroup'>
          <ActionIcon
            className='deleteBtn'
            variant='transparent'
            onClick={() => {
              setData((prev: ContextState) => ({ ...prev, compositionData: [], constraintData: initialConstraintData }));
              setTableData([]);
            }}
            disabled={!isFormFilled || !data.compositionData.length}
          >
            <MdDeleteForever size={32} />
          </ActionIcon>
          <Button
            size='compact-sm'
            disabled={!stoneSizes.length || !isFormFilled}
            variant='filled'
            onClick={() => table.setCreatingRow(true)}
          >
            {data.isStoneSizesFetching ? <Loader size={10} /> : "Add New"}
          </Button>
        </div>
      </div>
    ),
  });

  return (
    <div className='tableContainer' style={{ maxWidth: data.compositionMode === "advanced" ? "75%" : "50%" }}>
      <MantineReactTable table={table} />
    </div>
  );
};
