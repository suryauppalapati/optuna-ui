import { Notification } from "@mantine/core";
import { IconInfoCircle } from "@tabler/icons-react";

interface AlertBoxProps {
  title: "Error" | "Warning";
  message: string;
}

function AlertBox({ title, message }: AlertBoxProps) {
  const icon = <IconInfoCircle />;
  const colors = {
    Error: "red",
    Warning: "yellow",
  };
  return (
    <Notification variant='outline' color={colors[title]} withBorder title={title} icon={icon}>
      {message}
    </Notification>
  );
}

export default AlertBox;
