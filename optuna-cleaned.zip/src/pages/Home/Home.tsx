import SelectBrand from "../../components/SelectBrand";
import { Modal } from "@mantine/core";
import { useDisclosure } from "@mantine/hooks";
import "./Home.scss";
import { useEffect } from "react";
import JobStatus from "../../components/JobStatus";
import InputForm from "../../components/InputForm";
import BodyLayout from "../../components/BodyLayout";
import Results from "../../components/CompositionResults";

const Home = () => {
  const [opened, { open, close }] = useDisclosure(false);
  const [jobStatusOpen, { open: openJobStatus, close: closeJobStatus }] = useDisclosure(false);

  useEffect(open, []);

  return (
    <div className='root'>
      <Modal className='modal' opened={opened} onClose={close} centered closeOnClickOutside={false} closeOnEscape={false}>
        <SelectBrand closeOnSubmit={close} />
      </Modal>
      <Modal
        className='modal'
        opened={jobStatusOpen}
        onClose={closeJobStatus}
        centered
        closeOnClickOutside={false}
        closeOnEscape={false}
      >
        <JobStatus duration={420} closeJobStatus={closeJobStatus} />
      </Modal>
      <InputForm />
      <BodyLayout openJobStatus={openJobStatus} />
      <Results />
    </div>
  );
};

export default Home;
