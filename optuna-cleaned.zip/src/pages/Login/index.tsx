import { useState } from "react";
import { useForm } from "@mantine/form";
import styles from "./Login.module.scss";
import { notifications } from "@mantine/notifications";
import { TextInput, Button, Group, Loader } from "@mantine/core";
import { ContextState, useAttributeData } from "../../context/AttributeContext";

function Login() {
  const { setData } = useAttributeData();
  const [loading, setLoading] = useState<boolean>(false);

  const form = useForm({
    initialValues: {
      email: "",
      password: "",
    },
    validate: {
      email: (value) =>
        !value ? "Email must not be empty" : value.endsWith("@titan.co.in") ? null : "Email must end with '@titan.co.in'",
      password: (value) => (value.length >= 6 ? null : "Password must not be empty"),
    },
    validateInputOnBlur: true,
  });

  const handleSubmit = form.onSubmit((values) => {
    if (values.email && values.password === "TitanOGC@123!") {
      setLoading(true);
      setTimeout(() => {
        sessionStorage.setItem("isLoggedIn", "true");
        setData((prev: ContextState) => ({ ...prev, isLoggedIn: true }));
        setLoading(false);
      }, 1500);
    } else {
      notifications.show({
        color: "red",
        style: { fontSize: "1rem" },
        withBorder: true,
        position: "top-right",
        title: "Error",
        message: "Invalid login credentials",
      });
    }
  });

  return (
    <div className={styles.login}>
      <form onSubmit={handleSubmit}>
        <TextInput className={styles.input} label='Email' placeholder='Email' {...form.getInputProps("email")} />
        <TextInput
          className={styles.input}
          mt='md'
          label='Password'
          placeholder='Password'
          type='password'
          {...form.getInputProps("password")}
        />

        <Group justify='center' mt='xl'>
          <Button w='5rem' type='submit' disabled={!!(form.errors.email || form.errors.password)}>
            {loading ? <Loader color='white' size={15} /> : "Login"}
          </Button>
        </Group>
      </form>
    </div>
  );
}

export default Login;
