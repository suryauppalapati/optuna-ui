import "./ConstraintTable.scss";
import "@mantine/core/styles.css";
import "@mantine/dates/styles.css";
import "mantine-react-table/styles.css";
import { NumberInput } from "@mantine/core";
import { ConstraintData } from "../../types";
import { useState, useMemo } from "react";
import { useAttributeData, ContextState } from "../../context/AttributeContext";
import { MantineReactTable, useMantineReactTable, type MRT_ColumnDef, type MRT_TableOptions } from "mantine-react-table";

export default function ConstraintTable() {
  const [isCreatingRowData, setIsCreatingRowData] = useState<Partial<ConstraintData>>({});
  const { data, setData } = useAttributeData();

  const stringToKeyMappings: any = {
    "Gold weight": "gold_weight",
    "Stone count": "total_stone_count",
    "Total price": "total_product_price",
  };

  const columns = useMemo<MRT_ColumnDef<ConstraintData>[]>(
    () => [
      {
        accessorKey: "productConstraint",
        header: "Product Constraint",
        enableEditing: false,
      },
      {
        accessorKey: "minimum",
        header: "Minimum",
        Edit: ({ cell, row }) => (
          <NumberInput
            className='inputSelect'
            step={Number(row.id) === 2 ? 1000 : 1}
            prefix={Number(row.id) === 2 ? "₹" : ""}
            defaultValue={cell.getValue<number>() || 0}
            onChange={(value) => {
              setIsCreatingRowData((prev) => ({ ...prev, minimum: value as number }));
            }}
          />
        ),
      },
      {
        accessorKey: "maximum",
        header: "Maximum",
        Edit: ({ cell, row }) => (
          <NumberInput
            className='inputSelect'
            step={Number(row.id) === 2 ? 1000 : 1}
            prefix={Number(row.id) === 2 ? "₹" : ""}
            defaultValue={cell.getValue<number>() || 0}
            onChange={(value) => {
              setIsCreatingRowData((prev) => ({ ...prev, maximum: value as number }));
            }}
          />
        ),
      },
    ],
    []
  );

  const updateData = (newData: ConstraintData[]) => {
    setData((prev: ContextState) => ({
      ...prev,
      constraintData: newData,
    }));
  };

  const handleEditingRowSave: MRT_TableOptions<ConstraintData>["onEditingRowSave"] = async ({
    row,
    values,
    exitEditingMode,
  }) => {
    const newRow: ConstraintData = {
      productConstraint: stringToKeyMappings[values.productConstraint] as string,
      minimum: isCreatingRowData.minimum ?? values.minimum,
      maximum: isCreatingRowData.maximum ?? values.maximum,
    };

    // Find the index of the row by matching the unique productConstraint field
    const index = data.constraintData.findIndex(
      (constraint) => constraint.productConstraint === row.original.productConstraint
    );
    if (index === -1) {
      console.error("Row not found");
      exitEditingMode();
      return;
    }

    const newConstraintData = [...data.constraintData];
    newConstraintData[index] = newRow;
    updateData(newConstraintData);
    exitEditingMode();
  };

  const table = useMantineReactTable({
    columns: columns,
    data: data.constraintData,
    enableEditing: true,
    enableRowActions: false,
    createDisplayMode: "row",
    editDisplayMode: "row",
    enableFilters: false,
    enableFullScreenToggle: false,
    enableHiding: false,
    enableDensityToggle: false,
    enableSorting: false,
    enableColumnActions: false,
    mantineTableContainerProps: { style: { textAlign: "center" } },
    enablePagination: false,
    positionActionsColumn: "last",
    renderBottomToolbar: "",
    renderTopToolbar: "",
    onEditingRowSave: handleEditingRowSave,
  });

  return (
    <div className='constraintTable'>
      <MantineReactTable table={table} />
    </div>
  );
}
