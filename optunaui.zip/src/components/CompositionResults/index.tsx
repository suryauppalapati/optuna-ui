import styles from "./CompositionResults.module.scss";
import { ContextState, initialGCResultData, useAttributeData } from "../../context/AttributeContext";
import { useEffect } from "react";

const CompositionResults = () => {
  const {
    data: { gcResult, compositionMode },
    setData,
  } = useAttributeData();

  const basic_gc = [
    { label: "Total F1", value: gcResult.total_f1 },
    { label: "Total F2", value: gcResult.total_f2 },
    { label: "Metal Value", value: gcResult.metal_value },
    { label: "Total Price", value: gcResult.total_price },
    { label: "BMGC", value: gcResult.bmgc },
    { label: "GC", value: gcResult.gc },
  ];

  const adv_gc = [
    { label: "Stone Quantity", value: gcResult.total_quantity },
    { label: "Stone Weight", value: gcResult.total_stone_weight },
  ];

  const kpiData = compositionMode === "basic" ? basic_gc : [...adv_gc, ...basic_gc];
  const result = gcResult.gc && gcResult.bmgc && (gcResult.gc >= gcResult.bmgc ? "OK" : "NOT OK");

  useEffect(() => {
    setData((prev: ContextState) => ({ ...prev, gcResult: initialGCResultData }));
  }, [compositionMode]);

  return (
    <div className={styles.compositionResults}>
      <div className={styles.kpiGrid}>
        {kpiData.map((item, index) => (
          <div key={index} className={styles.kpiCard} style={{ minWidth: compositionMode === "basic" ? "180px" : "138px" }}>
            <span className={styles.metricLabel}>{item.label}</span>
            <span className={styles.metricValue}>
              {((item.label === "BMGC" || item.label === "GC") && typeof item.value === "number"
                ? `${(item.value * 100).toFixed(2)}%`
                : item.value) || "-"}
            </span>
          </div>
        ))}
      </div>
      <div className={styles.kpiCard} style={{ minWidth: compositionMode === "basic" ? "180px" : "138px" }}>
        <span className={styles.metricLabel}>Status</span>
        <span className={`${styles.metricValue} ${styles.result} ${styles.result} ${result === "NOT OK" && styles.failed}`}>
          {result || "-"}
        </span>
      </div>
    </div>
  );
};

export default CompositionResults;
