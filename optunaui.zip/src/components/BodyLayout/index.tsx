import React, { useRef, useState } from "react";
import { calculateGC, submitJobRequest } from "../../apis";
import styles from "./Layout.module.scss";
import { Button, Loader } from "@mantine/core";
import ConstraintTable from "../ConstraintTable";
import { CompositionTable } from "../CompositionTable";
import { ContextState, useAttributeData } from "../../context/AttributeContext";
import { createJobApiParams } from "../../utils";

const BodyLayout: React.FC<{ openJobStatus: () => void }> = ({ openJobStatus }) => {
  const { data, setData } = useAttributeData();
  const { formData, compositionData, constraintData, stoneAttributes } = data;
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const ref = useRef<HTMLDivElement | null>(null);

  const handleCalculateGC = async () => {
    setIsLoading(true);
    try {
      const response = await calculateGC(data.compositionData, data.formData, data.selectedBrand);
      setData((prev: ContextState) => ({ ...prev, gcResult: response }));
      // console.log("GC Calculator Response", response);
      setIsLoading(false);
    } catch (error) {
      console.error(error);
      setIsLoading(false);
    }
  };

  const submitJob = async () => {
    setIsLoading(true);
    try {
      const params = createJobApiParams(formData, constraintData, compositionData, stoneAttributes);
      const response = await submitJobRequest(params);
      setData((prev: ContextState) => ({ ...prev, jobId: response }));
      // console.log("Job Submitted ID: ", response);
      setIsLoading(false);
      openJobStatus();
    } catch (error) {
      console.error(error);
      setIsLoading(false);
    }
  };

  return (
    <div className={styles.root} ref={ref}>
      <div className={styles.tablesContainer}>
        <CompositionTable stoneSizes={data.stoneAttributes} />
        {data.compositionMode === "advanced" && <ConstraintTable />}
      </div>
      <Button
        className={styles.calBtn}
        disabled={!data.compositionData.length}
        onClick={data.compositionMode === "basic" ? handleCalculateGC : submitJob}
      >
        {isLoading ? <Loader size={15} color='white' /> : data.compositionMode === "basic" ? "Calculate" : "Submit Job"}
      </Button>
    </div>
  );
};

export default BodyLayout;
