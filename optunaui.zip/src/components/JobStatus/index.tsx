import styles from "./JobStatus.module.scss";
import { useState, useEffect } from "react";
import { IconCheck, IconX } from "@tabler/icons-react";
import { RingProgress, Center, ActionIcon, Button } from "@mantine/core";
import { notifications } from "@mantine/notifications";
import { useAttributeData } from "../../context/AttributeContext";
import { checkJobStatus } from "../../apis";

interface JobStatusProps {
  duration: number; // in seconds
  closeJobStatus: () => void;
}

const statusMessage = {
  running: "Please wait while we run your job!",
  completed: "Your job is completed!",
  failed: "Job failed, Please try again or contact your admin",
};

const JobStatus: React.FC<JobStatusProps> = ({ duration, closeJobStatus }) => {
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [jobState, setJobState] = useState<"running" | "completed" | "failed">("running");
  const { data } = useAttributeData();
  let elapsedTimer: any;

  const checkStatus = async () => {
    if (!data.jobId) return;
    try {
      const response = await checkJobStatus(data.jobId);
      console.log("response.statusCode", response.statusCode);
      if (response.statusCode === 501) {
        clearInterval(elapsedTimer);
        setJobState("failed");
      } else if (response.statusCode === 200 && response.body) {
        clearInterval(elapsedTimer);
        setJobState("completed");
        notifications.show({
          color: "yellow",
          style: { fontSize: "2vw" },
          withBorder: true,
          position: "top-right",
          title: "Error",
          autoClose: false,
          message: response.body[0] || "Job completed!",
        });
      }
    } catch (error) {
      setJobState("failed");
      console.error(error);
    }
  };

  useEffect(() => {
    if (timeLeft < duration && jobState === "running") {
      elapsedTimer = setInterval(() => {
        setTimeLeft((prev) => {
          const newTimeLeft = prev + 1;
          // Check job status every 15 seconds
          if (newTimeLeft % 15 === 0) {
            checkStatus();
          }
          return newTimeLeft;
        });
      }, 1000);

      return () => clearInterval(elapsedTimer);
    }
  }, [jobState, duration]);

  const progress: number = (timeLeft / duration) * 100;

  return (
    <div className={styles.jobStatus}>
      <p>{statusMessage[jobState]}</p>
      <RingProgress
        sections={[{ value: jobState === "completed" ? 100 : progress, color: jobState === "failed" ? "red" : "teal" }]}
        label={
          jobState !== "failed" ? (
            <Center>
              {timeLeft > duration || jobState === "completed" ? (
                <ActionIcon color='teal' variant='light' radius='xl' size='xl'>
                  <IconCheck size={22} />
                </ActionIcon>
              ) : (
                <span>{timeLeft}s</span>
              )}
            </Center>
          ) : (
            <Center>
              <ActionIcon color='red' variant='light' radius='xl' size='xl'>
                <IconX size={22} color='red' />
              </ActionIcon>
            </Center>
          )
        }
      />
      <Button
        color='red'
        onClick={() => {
          closeJobStatus();
          notifications.clean();
        }}
      >
        Close
      </Button>
    </div>
  );
};

export default JobStatus;
