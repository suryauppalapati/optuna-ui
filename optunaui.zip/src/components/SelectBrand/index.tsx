import { useState } from "react";
import styles from "./SelectBrand.module.scss";
import { AttributeData, BrandOptions } from "../../types";
import TanishqLogo from "../../assets/tanishq-logo.avif";
import MiaLogo from "../../assets/mia-logo.jpg";
import { Button, Loader } from "@mantine/core";
import { FaCheckCircle } from "react-icons/fa";
import { getBrandAttributes } from "../../apis";
import { ContextState, useAttributeData } from "../../context/AttributeContext";

type SelectBrandProps = {
  closeOnSubmit: () => void;
};

const SelectBrand: React.FC<SelectBrandProps> = ({ closeOnSubmit }) => {
  const [selectedBrand, setSelectedBrand] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const { setData } = useAttributeData();

  const brandOptions: BrandOptions[] = [
    { name: "Tanishq", logoUrl: TanishqLogo },
    { name: "Mia", logoUrl: MiaLogo },
  ];

  const handleSubmit = async () => {
    setIsLoading(true);
    setData((prev: ContextState) => ({ ...prev, selectedBrand: selectedBrand }));
    const response = await getBrandAttributes(selectedBrand.toUpperCase());

    if (response) {
      setData((prev: AttributeData) => ({
        ...prev,
        brandAttributes: response,
      }));
      closeOnSubmit();
      setIsLoading(false);
    } else {
      setIsLoading(false);
    }
  };

  return (
    <div className={styles.root}>
      <div className={styles.intro}>
        <p>Welcome Back,</p>
        <p>Please select your brand to continue</p>
      </div>
      <div className={styles.brandOptions}>
        {brandOptions.map((brand) => (
          <div onClick={() => setSelectedBrand(brand.name)} className={styles.brandOptionCard} key={brand.name}>
            <img src={brand.logoUrl} alt={`${brand.name}-logo`} />
            {brand.name === selectedBrand && <FaCheckCircle />}
          </div>
        ))}
      </div>
      <div className={styles.cta}>
        <Button style={{ width: "8vw" }} disabled={!selectedBrand || isLoading} onClick={handleSubmit}>
          {!isLoading ? "Continue" : <Loader size={15} className={styles.loader} />}
        </Button>
      </div>
    </div>
  );
};

export default SelectBrand;
