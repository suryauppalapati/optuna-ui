import { TextInput, Select } from "@mantine/core";
import { useForm } from "@mantine/form";
import { useEffect } from "react";
import styles from "./InputForm.module.scss";
import { createOptions } from "../../utils";
import { postStoneAttributes } from "../../apis";
import { ContextState, useAttributeData } from "../../context/AttributeContext";

const InputForm = () => {
  const { data, setData } = useAttributeData();
  const { formData } = data;

  const options = createOptions(data.brandAttributes);

  const form = useForm({
    initialValues: {
      design_reference: formData.design_reference || "",
      product_category: formData.product_category || "",
      product_group: formData.product_group || "",
      need_state: formData.need_state || "",
      karatage: formData.karatage || "",
      stone_category: formData.stone_category || "",
      stone_quality: formData.stone_quality || "",
      stone_color: formData.stone_color || "",
      product_weight: formData.product_weight || "",
    },
    validate: {
      design_reference: (value) => (value.trim().length > 0 ? null : "Design reference is required"),
      product_category: (value) => (value.trim().length > 0 ? null : "Product category is required"),
      product_group: (value) => (value.trim().length > 0 ? null : "Product group is required"),
      need_state: (value) => (value.trim().length > 0 ? null : "Need state is required"),
      karatage: (value) => (value.trim().length > 0 ? null : "Karatage is required"),
      stone_category: (value) => (value.trim().length > 0 ? null : "Stone category is required"),
      stone_quality: (value) => (value.trim().length > 0 ? null : "Stone quality is required"),
      stone_color: (value) => (value.trim().length > 0 ? null : "Stone color is required"),
      product_weight: (value) => (value.trim().length > 0 ? null : "Product weight must be a number"),
    },
    validateInputOnBlur: true,
  });

  const handleFieldChange = (fieldName: keyof typeof form.values, value: string) => {
    form.setFieldValue(fieldName, value);
    setData((prev: ContextState) => ({
      ...prev,
      formData: { ...prev.formData, [fieldName]: value },
    }));
  };

  useEffect(() => {
    const { stone_color, stone_quality, stone_category } = data.formData;
    if (stone_color && stone_quality && stone_category) {
      setData((prev: ContextState) => ({ ...prev, isStoneSizesFetching: true }));

      const fetchStoneSizes = async () => {
        try {
          const stoneSizes = await postStoneAttributes({ stone_color, stone_quality, stone_category });
          setData((prev: ContextState) => ({
            ...prev,
            stoneAttributes: stoneSizes,
            isStoneSizesFetching: false,
          }));
        } catch {
          console.error("STONE SIZE FETCHING FAILED");
          setData((prev: ContextState) => ({
            ...prev,
            isStoneSizesFetching: false,
          }));
        }
      };

      fetchStoneSizes();
    }
  }, [data.formData.stone_color, data.formData.stone_quality, data.formData.stone_category]);

  return (
    <form
      className={styles.inputForm}
      onSubmit={form.onSubmit((values) => {
        console.log("Mantine form values:", values);
      })}
    >
      <TextInput
        className={styles.input}
        size='md'
        label='Design Reference'
        placeholder='Enter reference'
        required
        error={form.errors.design_reference}
        value={form.values.design_reference}
        onChange={(e) => handleFieldChange("design_reference", e.target.value)}
        onBlur={() => form.validateField("design_reference")}
      />

      <Select
        className={styles.input}
        size='md'
        label='Product Category'
        data={options.product_category}
        required
        error={form.errors.product_category}
        value={form.values.product_category}
        onChange={(value) => handleFieldChange("product_category", value || "")}
        onBlur={() => form.validateField("product_category")}
      />

      <Select
        className={styles.input}
        size='md'
        label='Product Group'
        data={options.product_group}
        required
        error={form.errors.product_group}
        value={form.values.product_group}
        onChange={(value) => handleFieldChange("product_group", value || "")}
        onBlur={() => form.validateField("product_group")}
      />

      <Select
        className={styles.input}
        size='md'
        label='Need State'
        data={options.need_state}
        required
        error={form.errors.need_state}
        value={form.values.need_state}
        onChange={(value) => handleFieldChange("need_state", value || "")}
        onBlur={() => form.validateField("need_state")}
      />

      <Select
        className={styles.input}
        size='md'
        label='Karatage'
        data={[
          { value: "14", label: "14" },
          { value: "18", label: "18" },
          { value: "22", label: "22" },
          // { value: "24", label: "24" },
        ]}
        required
        error={form.errors.karatage}
        value={form.values.karatage}
        onChange={(value) => handleFieldChange("karatage", value || "")}
        onBlur={() => form.validateField("karatage")}
      />

      <Select
        className={styles.input}
        size='md'
        label='Stone Category'
        data={options.stone_category}
        required
        error={form.errors.stone_category}
        value={form.values.stone_category}
        onChange={(value) => handleFieldChange("stone_category", value || "")}
        onBlur={() => form.validateField("stone_category")}
      />

      <Select
        className={styles.input}
        size='md'
        label='Stone Quality'
        data={options.stone_quality}
        required
        error={form.errors.stone_quality}
        value={form.values.stone_quality}
        onChange={(value) => handleFieldChange("stone_quality", value || "")}
        onBlur={() => form.validateField("stone_quality")}
      />

      <Select
        className={styles.input}
        size='md'
        label='Stone Color'
        data={options.stone_color}
        required
        error={form.errors.stone_color}
        value={form.values.stone_color}
        onChange={(value) => handleFieldChange("stone_color", value || "")}
        onBlur={() => form.validateField("stone_color")}
      />

      <TextInput
        className={styles.input}
        size='md'
        label='Product Weight'
        placeholder='Enter weight'
        required
        error={form.errors.product_weight}
        value={form.values.product_weight}
        onChange={(e) => handleFieldChange("product_weight", e.target.value)}
        onBlur={() => form.validateField("product_weight")}
      />
    </form>
  );
};

export default InputForm;
