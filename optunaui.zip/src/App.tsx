import "@mantine/core/styles.css";
import "@mantine/notifications/styles.css";
import { MantineProvider } from "@mantine/core";
import { Notifications } from "@mantine/notifications";
import theme from "./theme";
import Home from "./pages/Home/Home";
import "mantine-react-table/styles.css";
import { QueryClientProvider, QueryClient } from "@tanstack/react-query";
import { AttributeDataProvider, ContextState, useAttributeData } from "./context/AttributeContext";
import Login from "./pages/Login";
import { useState, useEffect } from "react";

// Create QueryClient outside of component to prevent re-creation
const queryClient = new QueryClient();

const AppContent = () => {
  const { data, setData } = useAttributeData();
  const [isLoggedIn, setIsLoggedIn] = useState<"true" | "false">(
    (sessionStorage.getItem("isLoggedIn") as "true" | "false") ?? "false"
  );

  useEffect(() => {
    const sessionStatus = sessionStorage.getItem("isLoggedIn");
    if (sessionStatus === "true") {
      setData((prev: ContextState) => ({ ...prev, isLoggedIn: "true" }));
      setIsLoggedIn("true");
    }
  }, [data.isLoggedIn, setData]);

  return isLoggedIn === "true" ? <Home /> : <Login />;
};

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <AttributeDataProvider>
        <MantineProvider theme={theme}>
          <Notifications />
          <AppContent />
        </MantineProvider>
      </AttributeDataProvider>
    </QueryClientProvider>
  );
};

export default App;
