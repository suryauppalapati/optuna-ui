import { createContext, useContext, useState, ReactNode } from "react";
import { JewelryBrandAttrs, Composition, ConstraintData, FormState, CalculatedGCResult } from "../types";

export type ContextState = {
  isLoggedIn: "true" | "false";
  selectedBrand: string;
  brandAttributes: JewelryBrandAttrs | {};
  productAttributes: any[];
  stoneAttributes: number[];
  compositionData: Composition[];
  constraintData: ConstraintData[];
  compositionMode: "basic" | "advanced";
  isStoneSizesFetching: boolean;
  isGCResultFetching: boolean;
  gcResult: CalculatedGCResult;
  formData: FormState;
  jobId: string | null;
};

const initialFormState: FormState = {
  design_reference: "",
  product_category: "",
  product_group: "",
  need_state: "",
  karatage: "",
  stone_category: "",
  stone_quality: "",
  stone_color: "",
  product_weight: "",
};

export const initialConstraintData: ConstraintData[] = [
  { productConstraint: "Gold weight", minimum: null, maximum: null },
  { productConstraint: "Stone count", minimum: null, maximum: null },
  { productConstraint: "Total price", minimum: null, maximum: null },
];

export const initialGCResultData: CalculatedGCResult = {
  total_f1: "",
  total_f2: "",
  metal_value: "",
  total_price: "",
  bmgc: "",
  gc: "",
};

const initialState: ContextState = {
  isLoggedIn: "false",
  selectedBrand: "",
  brandAttributes: {},
  productAttributes: [],
  stoneAttributes: [],
  compositionData: [],
  constraintData: initialConstraintData,
  compositionMode: "basic",
  formData: initialFormState,
  isStoneSizesFetching: false,
  isGCResultFetching: false,
  gcResult: initialGCResultData,
  jobId: null,
};

// Context type
interface AttributeDataContextType {
  data: ContextState;
  setData: (newData: any) => void;
}

// Create context with default values
const AttributeDataContext = createContext<AttributeDataContextType | undefined>(undefined);

// Context Provider Component
export const AttributeDataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [data, setData] = useState<ContextState>(initialState);

  return <AttributeDataContext.Provider value={{ data, setData }}>{children}</AttributeDataContext.Provider>;
};

// Custom hook to use the context..
export const useAttributeData = (): AttributeDataContextType => {
  const context = useContext(AttributeDataContext);
  return context ?? { data: initialState, setData: () => {} };
};
