import axios from "axios";
import { FormState, StoneAttributes, JewelryBrandAttrs, CalculatedGCResult, Composition } from "../types";
import { createStoneConfigParams } from "../utils";

axios.defaults.baseURL = "https://hanlqv7ry9.execute-api.ap-south-1.amazonaws.com/dev";

export const getBrandAttributes = async (brandName: string): Promise<JewelryBrandAttrs> => {
  if (!brandName || brandName.trim() === "") {
    throw new Error("Brand name must be provided and cannot be empty.");
  }

  try {
    const response = await axios.get(`/unique_product_attr_field_values?brand=${encodeURIComponent(brandName)}`);
    return response.data;
  } catch (error) {
    throw new Error("Error fetching brand attributes: " + (error as Error).message);
  }
};

export const calculateGC = async (
  compositionData: Composition[],
  brandAttributes: FormState,
  brandName: string
): Promise<CalculatedGCResult> => {
  if (!Object.keys(brandAttributes).length) {
    throw new Error("No brand attributes provided.");
  }

  try {
    const stoneConfigParams = createStoneConfigParams(compositionData);
    // console.log("stoneConfigParams", stoneConfigParams);

    const { design_reference, product_weight, karatage, ...filteredBrandAttrs } = brandAttributes;

    const params = {
      ...filteredBrandAttrs,
      stone_config: stoneConfigParams,
      brand: brandName.toUpperCase(),
      product_weight: parseFloat(product_weight).toString(),
      karatage: parseInt(karatage),
    };

    const results = await axios.post("/calculator_gc", params);
    return results.data;
  } catch (error) {
    throw new Error("Error calculating GC: " + (error as Error).message);
  }
};

export const postStoneAttributes = async (params: StoneAttributes): Promise<number[]> => {
  try {
    const response = await axios.post("/stone_sizes", params);
    return response.data;
  } catch (error) {
    throw new Error("Error posting stone attributes: " + (error as Error).message);
  }
};

export const submitJobRequest = async (params: any): Promise<any> => {
  try {
    const response = await axios.post("/submit-job", params);
    return response.data.job_id;
  } catch (error) {
    throw new Error("Error submitting Job Request: " + (error as Error).message);
  }
};

export const checkJobStatus = async (jobId: string): Promise<any> => {
  try {
    const response = await axios.post("/check-status", { jobId });
    return response.data;
  } catch (error) {
    throw new Error("Error Checking Job Status: " + (error as Error).message);
  }
};
