import { Option, Composition, StoneConfig, ConstraintData, FormState } from "../types";

export function createOptions(data: Record<string, any[]>): Record<string, Option[]> {
  const options: Record<string, Option[]> = {};

  for (const key in data) {
    if (Array.isArray(data[key])) {
      // To Flatten any nested arrays (like stone_category from response..)
      const flatArray = data[key].flat();

      options[key] = flatArray.map((item) => ({ value: item, label: item }));
    }
  }

  return options;
}

export function createStoneConfigParams(params: Composition[]): StoneConfig[] {
  const stoneConfig = [];
  for (const key in params)
    stoneConfig.push({ stone_size: params[key]["stoneSize"], stone_count: params[key]["stoneQuantity"] });
  return stoneConfig;
}

// Job Param Utils

function constructProductFilters(formData: FormState, constraintData: ConstraintData[]) {
  const constraintParams = constraintData.reduce((accumulator: any, current: ConstraintData) => {
    accumulator[current.productConstraint] = {
      mode: "continuous",
      lower_bound: current.minimum,
      upper_bound: current.maximum,
    };
    return accumulator;
  }, {});
  return {
    ...constraintParams,
    stone_quality: {
      mode: "categorical",
      values: [formData.stone_quality],
    },
    stone_color: {
      mode: "categorical",
      values: [formData.stone_color],
    },
  };
}

function constructGroupFilters(compositionData: Composition[], stoneSizes: number[]) {
  const groupFilterParams = compositionData.reduce((accumulator: any, current: Composition) => {
    const selectedStoneSizeIndex = stoneSizes.indexOf(current.stoneSize);
    const stoneSizesInitialIndex = 0;
    const stoneSizeFinalIndex = stoneSizes.length - 1;

    // Calculate the upper and lower bounds based on the selected stone size and tolerance
    const upper_bound = selectedStoneSizeIndex + current.stoneSizeTolerance!;
    const lower_bound = selectedStoneSizeIndex - current.stoneSizeTolerance!;

    // Clamp the lower and upper bounds within the valid index range
    const clampedLowerBound = Math.max(stoneSizesInitialIndex, Math.min(stoneSizeFinalIndex, lower_bound));
    const clampedUpperBound = Math.max(stoneSizesInitialIndex, Math.min(stoneSizeFinalIndex, upper_bound));

    // Ensure valid bounds for accessing stoneSizes
    const lowerBoundValue = stoneSizes[clampedLowerBound];
    const upperBoundValue = stoneSizes[clampedUpperBound];

    accumulator.push({
      stone_size: {
        mode: "continuous",
        lower_bound: lowerBoundValue,
        upper_bound: upperBoundValue,
      },
      stone_count: {
        mode: "continuous",
        lower_bound: current.minStoneQuantity,
        upper_bound: current.maxStoneQuantity,
      },
    });

    return accumulator;
  }, []);

  return groupFilterParams;
}

export function createJobApiParams(
  formData: FormState,
  constraintData: ConstraintData[],
  compositionData: Composition[],
  stoneSizes: number[]
) {
  const { product_group, need_state, product_category: category, karatage: gold_karat } = formData;

  const product_parameters = { product_group, need_state, category, gold_karat: Number(gold_karat), stone_type: "All" };
  const product_filters = constructProductFilters(formData, constraintData);
  const group_filters = constructGroupFilters(compositionData, stoneSizes);

  const params = {
    product_parameters: product_parameters,
    design_json: {
      product_filters,
      group_filters,
      group_constraints: [],
    },
    gold_rate_22k: 7800,
    num_jobs: 5,
    num_trials: 2500,
    best_trials: 3,
  };

  return params;
}
